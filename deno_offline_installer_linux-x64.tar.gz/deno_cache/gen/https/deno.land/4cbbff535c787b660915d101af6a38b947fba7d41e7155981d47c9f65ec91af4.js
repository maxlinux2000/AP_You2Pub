// Copyright 2018-2024 the Deno authors. All rights reserved. MIT license.
import { dirname } from "../path/dirname.ts";
import { ensureDir, ensureDirSync } from "./ensure_dir.ts";
import { toPathString } from "./_to_path_string.ts";
/**
 * Asynchronously ensures that the hard link exists. If the directory structure
 * does not exist, it is created.
 *
 * @param src The source file path as a string or URL. Directory hard links are
 * not allowed.
 * @param dest The destination link path as a string or URL.
 * @returns A void promise that resolves once the hard link exists.
 *
 * @example
 * ```ts
 * import { ensureLink } from "https://deno.land/std@$STD_VERSION/fs/ensure_link.ts";
 *
 * await ensureLink("./folder/targetFile.dat", "./folder/targetFile.link.dat");
 * ```
 */ export async function ensureLink(src, dest) {
  dest = toPathString(dest);
  await ensureDir(dirname(dest));
  await Deno.link(toPathString(src), dest);
}
/**
 * Synchronously ensures that the hard link exists. If the directory structure
 * does not exist, it is created.
 *
 * @param src The source file path as a string or URL. Directory hard links are
 * not allowed.
 * @param dest The destination link path as a string or URL.
 * @returns A void value that returns once the hard link exists.
 *
 * @example
 * ```ts
 * import { ensureLinkSync } from "https://deno.land/std@$STD_VERSION/fs/ensure_link.ts";
 *
 * ensureLinkSync("./folder/targetFile.dat", "./folder/targetFile.link.dat");
 * ```
 */ export function ensureLinkSync(src, dest) {
  dest = toPathString(dest);
  ensureDirSync(dirname(dest));
  Deno.linkSync(toPathString(src), dest);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjIyNC4wL2ZzL2Vuc3VyZV9saW5rLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIENvcHlyaWdodCAyMDE4LTIwMjQgdGhlIERlbm8gYXV0aG9ycy4gQWxsIHJpZ2h0cyByZXNlcnZlZC4gTUlUIGxpY2Vuc2UuXG5pbXBvcnQgeyBkaXJuYW1lIH0gZnJvbSBcIi4uL3BhdGgvZGlybmFtZS50c1wiO1xuaW1wb3J0IHsgZW5zdXJlRGlyLCBlbnN1cmVEaXJTeW5jIH0gZnJvbSBcIi4vZW5zdXJlX2Rpci50c1wiO1xuaW1wb3J0IHsgdG9QYXRoU3RyaW5nIH0gZnJvbSBcIi4vX3RvX3BhdGhfc3RyaW5nLnRzXCI7XG5cbi8qKlxuICogQXN5bmNocm9ub3VzbHkgZW5zdXJlcyB0aGF0IHRoZSBoYXJkIGxpbmsgZXhpc3RzLiBJZiB0aGUgZGlyZWN0b3J5IHN0cnVjdHVyZVxuICogZG9lcyBub3QgZXhpc3QsIGl0IGlzIGNyZWF0ZWQuXG4gKlxuICogQHBhcmFtIHNyYyBUaGUgc291cmNlIGZpbGUgcGF0aCBhcyBhIHN0cmluZyBvciBVUkwuIERpcmVjdG9yeSBoYXJkIGxpbmtzIGFyZVxuICogbm90IGFsbG93ZWQuXG4gKiBAcGFyYW0gZGVzdCBUaGUgZGVzdGluYXRpb24gbGluayBwYXRoIGFzIGEgc3RyaW5nIG9yIFVSTC5cbiAqIEByZXR1cm5zIEEgdm9pZCBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSB0aGUgaGFyZCBsaW5rIGV4aXN0cy5cbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHNcbiAqIGltcG9ydCB7IGVuc3VyZUxpbmsgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQvc3RkQCRTVERfVkVSU0lPTi9mcy9lbnN1cmVfbGluay50c1wiO1xuICpcbiAqIGF3YWl0IGVuc3VyZUxpbmsoXCIuL2ZvbGRlci90YXJnZXRGaWxlLmRhdFwiLCBcIi4vZm9sZGVyL3RhcmdldEZpbGUubGluay5kYXRcIik7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGVuc3VyZUxpbmsoc3JjOiBzdHJpbmcgfCBVUkwsIGRlc3Q6IHN0cmluZyB8IFVSTCkge1xuICBkZXN0ID0gdG9QYXRoU3RyaW5nKGRlc3QpO1xuICBhd2FpdCBlbnN1cmVEaXIoZGlybmFtZShkZXN0KSk7XG5cbiAgYXdhaXQgRGVuby5saW5rKHRvUGF0aFN0cmluZyhzcmMpLCBkZXN0KTtcbn1cblxuLyoqXG4gKiBTeW5jaHJvbm91c2x5IGVuc3VyZXMgdGhhdCB0aGUgaGFyZCBsaW5rIGV4aXN0cy4gSWYgdGhlIGRpcmVjdG9yeSBzdHJ1Y3R1cmVcbiAqIGRvZXMgbm90IGV4aXN0LCBpdCBpcyBjcmVhdGVkLlxuICpcbiAqIEBwYXJhbSBzcmMgVGhlIHNvdXJjZSBmaWxlIHBhdGggYXMgYSBzdHJpbmcgb3IgVVJMLiBEaXJlY3RvcnkgaGFyZCBsaW5rcyBhcmVcbiAqIG5vdCBhbGxvd2VkLlxuICogQHBhcmFtIGRlc3QgVGhlIGRlc3RpbmF0aW9uIGxpbmsgcGF0aCBhcyBhIHN0cmluZyBvciBVUkwuXG4gKiBAcmV0dXJucyBBIHZvaWQgdmFsdWUgdGhhdCByZXR1cm5zIG9uY2UgdGhlIGhhcmQgbGluayBleGlzdHMuXG4gKlxuICogQGV4YW1wbGVcbiAqIGBgYHRzXG4gKiBpbXBvcnQgeyBlbnN1cmVMaW5rU3luYyB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAJFNURF9WRVJTSU9OL2ZzL2Vuc3VyZV9saW5rLnRzXCI7XG4gKlxuICogZW5zdXJlTGlua1N5bmMoXCIuL2ZvbGRlci90YXJnZXRGaWxlLmRhdFwiLCBcIi4vZm9sZGVyL3RhcmdldEZpbGUubGluay5kYXRcIik7XG4gKiBgYGBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVuc3VyZUxpbmtTeW5jKHNyYzogc3RyaW5nIHwgVVJMLCBkZXN0OiBzdHJpbmcgfCBVUkwpIHtcbiAgZGVzdCA9IHRvUGF0aFN0cmluZyhkZXN0KTtcbiAgZW5zdXJlRGlyU3luYyhkaXJuYW1lKGRlc3QpKTtcblxuICBEZW5vLmxpbmtTeW5jKHRvUGF0aFN0cmluZyhzcmMpLCBkZXN0KTtcbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSwwRUFBMEU7QUFDMUUsU0FBUyxPQUFPLFFBQVEscUJBQXFCO0FBQzdDLFNBQVMsU0FBUyxFQUFFLGFBQWEsUUFBUSxrQkFBa0I7QUFDM0QsU0FBUyxZQUFZLFFBQVEsdUJBQXVCO0FBRXBEOzs7Ozs7Ozs7Ozs7Ozs7Q0FlQyxHQUNELE9BQU8sZUFBZSxXQUFXLEdBQWlCLEVBQUUsSUFBa0I7RUFDcEUsT0FBTyxhQUFhO0VBQ3BCLE1BQU0sVUFBVSxRQUFRO0VBRXhCLE1BQU0sS0FBSyxJQUFJLENBQUMsYUFBYSxNQUFNO0FBQ3JDO0FBRUE7Ozs7Ozs7Ozs7Ozs7OztDQWVDLEdBQ0QsT0FBTyxTQUFTLGVBQWUsR0FBaUIsRUFBRSxJQUFrQjtFQUNsRSxPQUFPLGFBQWE7RUFDcEIsY0FBYyxRQUFRO0VBRXRCLEtBQUssUUFBUSxDQUFDLGFBQWEsTUFBTTtBQUNuQyJ9
// denoCacheMetadata=15772156351977703562,4954832724693554467