// Copyright 2018-2024 the Deno authors. All rights reserved. MIT license.
import { isSubdir } from "./_is_subdir.ts";
import { isSamePath } from "./_is_same_path.ts";
const EXISTS_ERROR = new Deno.errors.AlreadyExists("dest already exists.");
/**
 * Error thrown in {@linkcode move} or {@linkcode moveSync} when the
 * destination is a subdirectory of the source.
 */ export class SubdirectoryMoveError extends Error {
  /** Constructs a new instance. */ constructor(src, dest){
    super(`Cannot move '${src}' to a subdirectory of itself, '${dest}'.`);
    this.name = this.constructor.name;
  }
}
/**
 * Asynchronously moves a file or directory.
 *
 * @param src The source file or directory as a string or URL.
 * @param dest The destination file or directory as a string or URL.
 * @param options Options for the move operation.
 * @returns A void promise that resolves once the operation completes.
 *
 * @example Basic usage
 * ```ts
 * import { move } from "https://deno.land/std@$STD_VERSION/fs/move.ts";
 *
 * await move("./foo", "./bar");
 * ```
 *
 * This will move the file or directory at `./foo` to `./bar` without
 * overwriting.
 *
 * @example Overwriting
 * ```ts
 * import { move } from "https://deno.land/std@$STD_VERSION/fs/move.ts";
 *
 * await move("./foo", "./bar", { overwrite: true });
 * ```
 *
 * This will move the file or directory at `./foo` to `./bar`, overwriting
 * `./bar` if it already exists.
 */ export async function move(src, dest, { overwrite = false } = {}) {
  const srcStat = await Deno.stat(src);
  if (srcStat.isDirectory && (isSubdir(src, dest) || isSamePath(src, dest))) {
    throw new SubdirectoryMoveError(src, dest);
  }
  if (overwrite) {
    if (isSamePath(src, dest)) return;
    try {
      await Deno.remove(dest, {
        recursive: true
      });
    } catch (error) {
      if (!(error instanceof Deno.errors.NotFound)) {
        throw error;
      }
    }
  } else {
    try {
      await Deno.lstat(dest);
      return Promise.reject(EXISTS_ERROR);
    } catch  {
    // Do nothing...
    }
  }
  await Deno.rename(src, dest);
}
/**
 * Synchronously moves a file or directory.
 *
 * @param src The source file or directory as a string or URL.
 * @param dest The destination file or directory as a string or URL.
 * @param options Options for the move operation.
 * @returns A void value that returns once the operation completes.
 *
 * @example Basic usage
 * ```ts
 * import { moveSync } from "https://deno.land/std@$STD_VERSION/fs/move.ts";
 *
 * moveSync("./foo", "./bar");
 * ```
 *
 * This will move the file or directory at `./foo` to `./bar` without
 * overwriting.
 *
 * @example Overwriting
 * ```ts
 * import { moveSync } from "https://deno.land/std@$STD_VERSION/fs/move.ts";
 *
 * moveSync("./foo", "./bar", { overwrite: true });
 * ```
 *
 * This will move the file or directory at `./foo` to `./bar`, overwriting
 * `./bar` if it already exists.
 */ export function moveSync(src, dest, { overwrite = false } = {}) {
  const srcStat = Deno.statSync(src);
  if (srcStat.isDirectory && (isSubdir(src, dest) || isSamePath(src, dest))) {
    throw new SubdirectoryMoveError(src, dest);
  }
  if (overwrite) {
    if (isSamePath(src, dest)) return;
    try {
      Deno.removeSync(dest, {
        recursive: true
      });
    } catch (error) {
      if (!(error instanceof Deno.errors.NotFound)) {
        throw error;
      }
    }
  } else {
    try {
      Deno.lstatSync(dest);
      throw EXISTS_ERROR;
    } catch (error) {
      if (error === EXISTS_ERROR) {
        throw error;
      }
    }
  }
  Deno.renameSync(src, dest);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjIyNC4wL2ZzL21vdmUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLy8gQ29weXJpZ2h0IDIwMTgtMjAyNCB0aGUgRGVubyBhdXRob3JzLiBBbGwgcmlnaHRzIHJlc2VydmVkLiBNSVQgbGljZW5zZS5cbmltcG9ydCB7IGlzU3ViZGlyIH0gZnJvbSBcIi4vX2lzX3N1YmRpci50c1wiO1xuaW1wb3J0IHsgaXNTYW1lUGF0aCB9IGZyb20gXCIuL19pc19zYW1lX3BhdGgudHNcIjtcblxuY29uc3QgRVhJU1RTX0VSUk9SID0gbmV3IERlbm8uZXJyb3JzLkFscmVhZHlFeGlzdHMoXCJkZXN0IGFscmVhZHkgZXhpc3RzLlwiKTtcblxuLyoqXG4gKiBFcnJvciB0aHJvd24gaW4ge0BsaW5rY29kZSBtb3ZlfSBvciB7QGxpbmtjb2RlIG1vdmVTeW5jfSB3aGVuIHRoZVxuICogZGVzdGluYXRpb24gaXMgYSBzdWJkaXJlY3Rvcnkgb2YgdGhlIHNvdXJjZS5cbiAqL1xuZXhwb3J0IGNsYXNzIFN1YmRpcmVjdG9yeU1vdmVFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgLyoqIENvbnN0cnVjdHMgYSBuZXcgaW5zdGFuY2UuICovXG4gIGNvbnN0cnVjdG9yKHNyYzogc3RyaW5nIHwgVVJMLCBkZXN0OiBzdHJpbmcgfCBVUkwpIHtcbiAgICBzdXBlcihcbiAgICAgIGBDYW5ub3QgbW92ZSAnJHtzcmN9JyB0byBhIHN1YmRpcmVjdG9yeSBvZiBpdHNlbGYsICcke2Rlc3R9Jy5gLFxuICAgICk7XG4gICAgdGhpcy5uYW1lID0gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lO1xuICB9XG59XG5cbi8qKiBPcHRpb25zIGZvciB7QGxpbmtjb2RlIG1vdmV9IGFuZCB7QGxpbmtjb2RlIG1vdmVTeW5jfS4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTW92ZU9wdGlvbnMge1xuICAvKipcbiAgICogV2hldGhlciB0aGUgZGVzdGluYXRpb24gZmlsZSBzaG91bGQgYmUgb3ZlcndyaXR0ZW4gaWYgaXQgYWxyZWFkeSBleGlzdHMuXG4gICAqXG4gICAqIEBkZWZhdWx0IHtmYWxzZX1cbiAgICovXG4gIG92ZXJ3cml0ZT86IGJvb2xlYW47XG59XG5cbi8qKlxuICogQXN5bmNocm9ub3VzbHkgbW92ZXMgYSBmaWxlIG9yIGRpcmVjdG9yeS5cbiAqXG4gKiBAcGFyYW0gc3JjIFRoZSBzb3VyY2UgZmlsZSBvciBkaXJlY3RvcnkgYXMgYSBzdHJpbmcgb3IgVVJMLlxuICogQHBhcmFtIGRlc3QgVGhlIGRlc3RpbmF0aW9uIGZpbGUgb3IgZGlyZWN0b3J5IGFzIGEgc3RyaW5nIG9yIFVSTC5cbiAqIEBwYXJhbSBvcHRpb25zIE9wdGlvbnMgZm9yIHRoZSBtb3ZlIG9wZXJhdGlvbi5cbiAqIEByZXR1cm5zIEEgdm9pZCBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgb25jZSB0aGUgb3BlcmF0aW9uIGNvbXBsZXRlcy5cbiAqXG4gKiBAZXhhbXBsZSBCYXNpYyB1c2FnZVxuICogYGBgdHNcbiAqIGltcG9ydCB7IG1vdmUgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQvc3RkQCRTVERfVkVSU0lPTi9mcy9tb3ZlLnRzXCI7XG4gKlxuICogYXdhaXQgbW92ZShcIi4vZm9vXCIsIFwiLi9iYXJcIik7XG4gKiBgYGBcbiAqXG4gKiBUaGlzIHdpbGwgbW92ZSB0aGUgZmlsZSBvciBkaXJlY3RvcnkgYXQgYC4vZm9vYCB0byBgLi9iYXJgIHdpdGhvdXRcbiAqIG92ZXJ3cml0aW5nLlxuICpcbiAqIEBleGFtcGxlIE92ZXJ3cml0aW5nXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgbW92ZSB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAJFNURF9WRVJTSU9OL2ZzL21vdmUudHNcIjtcbiAqXG4gKiBhd2FpdCBtb3ZlKFwiLi9mb29cIiwgXCIuL2JhclwiLCB7IG92ZXJ3cml0ZTogdHJ1ZSB9KTtcbiAqIGBgYFxuICpcbiAqIFRoaXMgd2lsbCBtb3ZlIHRoZSBmaWxlIG9yIGRpcmVjdG9yeSBhdCBgLi9mb29gIHRvIGAuL2JhcmAsIG92ZXJ3cml0aW5nXG4gKiBgLi9iYXJgIGlmIGl0IGFscmVhZHkgZXhpc3RzLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbW92ZShcbiAgc3JjOiBzdHJpbmcgfCBVUkwsXG4gIGRlc3Q6IHN0cmluZyB8IFVSTCxcbiAgeyBvdmVyd3JpdGUgPSBmYWxzZSB9OiBNb3ZlT3B0aW9ucyA9IHt9LFxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IHNyY1N0YXQgPSBhd2FpdCBEZW5vLnN0YXQoc3JjKTtcblxuICBpZiAoXG4gICAgc3JjU3RhdC5pc0RpcmVjdG9yeSAmJlxuICAgIChpc1N1YmRpcihzcmMsIGRlc3QpIHx8IGlzU2FtZVBhdGgoc3JjLCBkZXN0KSlcbiAgKSB7XG4gICAgdGhyb3cgbmV3IFN1YmRpcmVjdG9yeU1vdmVFcnJvcihzcmMsIGRlc3QpO1xuICB9XG5cbiAgaWYgKG92ZXJ3cml0ZSkge1xuICAgIGlmIChpc1NhbWVQYXRoKHNyYywgZGVzdCkpIHJldHVybjtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgRGVuby5yZW1vdmUoZGVzdCwgeyByZWN1cnNpdmU6IHRydWUgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmICghKGVycm9yIGluc3RhbmNlb2YgRGVuby5lcnJvcnMuTm90Rm91bmQpKSB7XG4gICAgICAgIHRocm93IGVycm9yO1xuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgRGVuby5sc3RhdChkZXN0KTtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChFWElTVFNfRVJST1IpO1xuICAgIH0gY2F0Y2gge1xuICAgICAgLy8gRG8gbm90aGluZy4uLlxuICAgIH1cbiAgfVxuXG4gIGF3YWl0IERlbm8ucmVuYW1lKHNyYywgZGVzdCk7XG59XG5cbi8qKlxuICogU3luY2hyb25vdXNseSBtb3ZlcyBhIGZpbGUgb3IgZGlyZWN0b3J5LlxuICpcbiAqIEBwYXJhbSBzcmMgVGhlIHNvdXJjZSBmaWxlIG9yIGRpcmVjdG9yeSBhcyBhIHN0cmluZyBvciBVUkwuXG4gKiBAcGFyYW0gZGVzdCBUaGUgZGVzdGluYXRpb24gZmlsZSBvciBkaXJlY3RvcnkgYXMgYSBzdHJpbmcgb3IgVVJMLlxuICogQHBhcmFtIG9wdGlvbnMgT3B0aW9ucyBmb3IgdGhlIG1vdmUgb3BlcmF0aW9uLlxuICogQHJldHVybnMgQSB2b2lkIHZhbHVlIHRoYXQgcmV0dXJucyBvbmNlIHRoZSBvcGVyYXRpb24gY29tcGxldGVzLlxuICpcbiAqIEBleGFtcGxlIEJhc2ljIHVzYWdlXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgbW92ZVN5bmMgfSBmcm9tIFwiaHR0cHM6Ly9kZW5vLmxhbmQvc3RkQCRTVERfVkVSU0lPTi9mcy9tb3ZlLnRzXCI7XG4gKlxuICogbW92ZVN5bmMoXCIuL2Zvb1wiLCBcIi4vYmFyXCIpO1xuICogYGBgXG4gKlxuICogVGhpcyB3aWxsIG1vdmUgdGhlIGZpbGUgb3IgZGlyZWN0b3J5IGF0IGAuL2Zvb2AgdG8gYC4vYmFyYCB3aXRob3V0XG4gKiBvdmVyd3JpdGluZy5cbiAqXG4gKiBAZXhhbXBsZSBPdmVyd3JpdGluZ1xuICogYGBgdHNcbiAqIGltcG9ydCB7IG1vdmVTeW5jIH0gZnJvbSBcImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAkU1REX1ZFUlNJT04vZnMvbW92ZS50c1wiO1xuICpcbiAqIG1vdmVTeW5jKFwiLi9mb29cIiwgXCIuL2JhclwiLCB7IG92ZXJ3cml0ZTogdHJ1ZSB9KTtcbiAqIGBgYFxuICpcbiAqIFRoaXMgd2lsbCBtb3ZlIHRoZSBmaWxlIG9yIGRpcmVjdG9yeSBhdCBgLi9mb29gIHRvIGAuL2JhcmAsIG92ZXJ3cml0aW5nXG4gKiBgLi9iYXJgIGlmIGl0IGFscmVhZHkgZXhpc3RzLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbW92ZVN5bmMoXG4gIHNyYzogc3RyaW5nIHwgVVJMLFxuICBkZXN0OiBzdHJpbmcgfCBVUkwsXG4gIHsgb3ZlcndyaXRlID0gZmFsc2UgfTogTW92ZU9wdGlvbnMgPSB7fSxcbik6IHZvaWQge1xuICBjb25zdCBzcmNTdGF0ID0gRGVuby5zdGF0U3luYyhzcmMpO1xuXG4gIGlmIChcbiAgICBzcmNTdGF0LmlzRGlyZWN0b3J5ICYmXG4gICAgKGlzU3ViZGlyKHNyYywgZGVzdCkgfHwgaXNTYW1lUGF0aChzcmMsIGRlc3QpKVxuICApIHtcbiAgICB0aHJvdyBuZXcgU3ViZGlyZWN0b3J5TW92ZUVycm9yKHNyYywgZGVzdCk7XG4gIH1cblxuICBpZiAob3ZlcndyaXRlKSB7XG4gICAgaWYgKGlzU2FtZVBhdGgoc3JjLCBkZXN0KSkgcmV0dXJuO1xuICAgIHRyeSB7XG4gICAgICBEZW5vLnJlbW92ZVN5bmMoZGVzdCwgeyByZWN1cnNpdmU6IHRydWUgfSk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmICghKGVycm9yIGluc3RhbmNlb2YgRGVuby5lcnJvcnMuTm90Rm91bmQpKSB7XG4gICAgICAgIHRocm93IGVycm9yO1xuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICB0cnkge1xuICAgICAgRGVuby5sc3RhdFN5bmMoZGVzdCk7XG4gICAgICB0aHJvdyBFWElTVFNfRVJST1I7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGlmIChlcnJvciA9PT0gRVhJU1RTX0VSUk9SKSB7XG4gICAgICAgIHRocm93IGVycm9yO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIERlbm8ucmVuYW1lU3luYyhzcmMsIGRlc3QpO1xufVxuIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLDBFQUEwRTtBQUMxRSxTQUFTLFFBQVEsUUFBUSxrQkFBa0I7QUFDM0MsU0FBUyxVQUFVLFFBQVEscUJBQXFCO0FBRWhELE1BQU0sZUFBZSxJQUFJLEtBQUssTUFBTSxDQUFDLGFBQWEsQ0FBQztBQUVuRDs7O0NBR0MsR0FDRCxPQUFPLE1BQU0sOEJBQThCO0VBQ3pDLCtCQUErQixHQUMvQixZQUFZLEdBQWlCLEVBQUUsSUFBa0IsQ0FBRTtJQUNqRCxLQUFLLENBQ0gsQ0FBQyxhQUFhLEVBQUUsSUFBSSxnQ0FBZ0MsRUFBRSxLQUFLLEVBQUUsQ0FBQztJQUVoRSxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSTtFQUNuQztBQUNGO0FBWUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQTJCQyxHQUNELE9BQU8sZUFBZSxLQUNwQixHQUFpQixFQUNqQixJQUFrQixFQUNsQixFQUFFLFlBQVksS0FBSyxFQUFlLEdBQUcsQ0FBQyxDQUFDO0VBRXZDLE1BQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxDQUFDO0VBRWhDLElBQ0UsUUFBUSxXQUFXLElBQ25CLENBQUMsU0FBUyxLQUFLLFNBQVMsV0FBVyxLQUFLLEtBQUssR0FDN0M7SUFDQSxNQUFNLElBQUksc0JBQXNCLEtBQUs7RUFDdkM7RUFFQSxJQUFJLFdBQVc7SUFDYixJQUFJLFdBQVcsS0FBSyxPQUFPO0lBQzNCLElBQUk7TUFDRixNQUFNLEtBQUssTUFBTSxDQUFDLE1BQU07UUFBRSxXQUFXO01BQUs7SUFDNUMsRUFBRSxPQUFPLE9BQU87TUFDZCxJQUFJLENBQUMsQ0FBQyxpQkFBaUIsS0FBSyxNQUFNLENBQUMsUUFBUSxHQUFHO1FBQzVDLE1BQU07TUFDUjtJQUNGO0VBQ0YsT0FBTztJQUNMLElBQUk7TUFDRixNQUFNLEtBQUssS0FBSyxDQUFDO01BQ2pCLE9BQU8sUUFBUSxNQUFNLENBQUM7SUFDeEIsRUFBRSxPQUFNO0lBQ04sZ0JBQWdCO0lBQ2xCO0VBQ0Y7RUFFQSxNQUFNLEtBQUssTUFBTSxDQUFDLEtBQUs7QUFDekI7QUFFQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMkJDLEdBQ0QsT0FBTyxTQUFTLFNBQ2QsR0FBaUIsRUFDakIsSUFBa0IsRUFDbEIsRUFBRSxZQUFZLEtBQUssRUFBZSxHQUFHLENBQUMsQ0FBQztFQUV2QyxNQUFNLFVBQVUsS0FBSyxRQUFRLENBQUM7RUFFOUIsSUFDRSxRQUFRLFdBQVcsSUFDbkIsQ0FBQyxTQUFTLEtBQUssU0FBUyxXQUFXLEtBQUssS0FBSyxHQUM3QztJQUNBLE1BQU0sSUFBSSxzQkFBc0IsS0FBSztFQUN2QztFQUVBLElBQUksV0FBVztJQUNiLElBQUksV0FBVyxLQUFLLE9BQU87SUFDM0IsSUFBSTtNQUNGLEtBQUssVUFBVSxDQUFDLE1BQU07UUFBRSxXQUFXO01BQUs7SUFDMUMsRUFBRSxPQUFPLE9BQU87TUFDZCxJQUFJLENBQUMsQ0FBQyxpQkFBaUIsS0FBSyxNQUFNLENBQUMsUUFBUSxHQUFHO1FBQzVDLE1BQU07TUFDUjtJQUNGO0VBQ0YsT0FBTztJQUNMLElBQUk7TUFDRixLQUFLLFNBQVMsQ0FBQztNQUNmLE1BQU07SUFDUixFQUFFLE9BQU8sT0FBTztNQUNkLElBQUksVUFBVSxjQUFjO1FBQzFCLE1BQU07TUFDUjtJQUNGO0VBQ0Y7RUFFQSxLQUFLLFVBQVUsQ0FBQyxLQUFLO0FBQ3ZCIn0=
// denoCacheMetadata=10723764653338746426,12809438216913820661