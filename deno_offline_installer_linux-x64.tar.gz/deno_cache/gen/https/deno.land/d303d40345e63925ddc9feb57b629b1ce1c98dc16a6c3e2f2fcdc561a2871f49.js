// Copyright 2018-2024 the Deno authors. All rights reserved. MIT license.
import { globToRegExp } from "../path/glob_to_regexp.ts";
import { joinGlobs } from "../path/join_globs.ts";
import { isGlob } from "../path/is_glob.ts";
import { isAbsolute } from "../path/is_absolute.ts";
import { resolve } from "../path/resolve.ts";
import { SEPARATOR_PATTERN } from "../path/constants.ts";
import { walk, walkSync } from "./walk.ts";
import { assert } from "../assert/assert.ts";
import { toPathString } from "./_to_path_string.ts";
import { createWalkEntry, createWalkEntrySync } from "./_create_walk_entry.ts";
const isWindows = Deno.build.os === "windows";
function split(path) {
  const s = SEPARATOR_PATTERN.source;
  const segments = path.replace(new RegExp(`^${s}|${s}$`, "g"), "").split(SEPARATOR_PATTERN);
  const isAbsolute_ = isAbsolute(path);
  return {
    segments,
    isAbsolute: isAbsolute_,
    hasTrailingSep: !!path.match(new RegExp(`${s}$`)),
    winRoot: isWindows && isAbsolute_ ? segments.shift() : undefined
  };
}
function throwUnlessNotFound(error) {
  if (!(error instanceof Deno.errors.NotFound)) {
    throw error;
  }
}
function comparePath(a, b) {
  if (a.path < b.path) return -1;
  if (a.path > b.path) return 1;
  return 0;
}
/**
 * Returns an async iterator that yields each file path matching the given glob
 * pattern. The file paths are relative to the provided `root` directory.
 * If `root` is not provided, the current working directory is used.
 * The `root` directory is not included in the yielded file paths.
 *
 * Requires the `--allow-read` flag.
 *
 * @param glob The glob pattern to expand.
 * @param options Additional options for the expansion.
 * @returns An async iterator that yields each walk entry matching the glob
 * pattern.
 *
 * @example Basic usage
 *
 * File structure:
 * ```
 * folder
 * ├── script.ts
 * └── foo.ts
 * ```
 *
 * ```ts
 * // script.ts
 * import { expandGlob } from "https://deno.land/std@$STD_VERSION/fs/expand_glob.ts";
 *
 * const entries = [];
 * for await (const entry of expandGlob("*.ts")) {
 *   entries.push(entry);
 * }
 *
 * entries[0]!.path; // "/Users/user/folder/script.ts"
 * entries[0]!.name; // "script.ts"
 * entries[0]!.isFile; // false
 * entries[0]!.isDirectory; // true
 * entries[0]!.isSymlink; // false
 *
 * entries[1]!.path; // "/Users/user/folder/foo.ts"
 * entries[1]!.name; // "foo.ts"
 * entries[1]!.isFile; // true
 * entries[1]!.isDirectory; // false
 * entries[1]!.isSymlink; // false
 * ```
 */ export async function* expandGlob(glob, { root, exclude = [], includeDirs = true, extended = true, globstar = true, caseInsensitive, followSymlinks, canonicalize } = {}) {
  const { segments, isAbsolute: isGlobAbsolute, hasTrailingSep, winRoot } = split(toPathString(glob));
  root ??= isGlobAbsolute ? winRoot ?? "/" : Deno.cwd();
  const globOptions = {
    extended,
    globstar,
    caseInsensitive
  };
  const absRoot = isGlobAbsolute ? root : resolve(root); // root is always string here
  const resolveFromRoot = (path)=>resolve(absRoot, path);
  const excludePatterns = exclude.map(resolveFromRoot).map((s)=>globToRegExp(s, globOptions));
  const shouldInclude = (path)=>!excludePatterns.some((p)=>!!path.match(p));
  let fixedRoot = isGlobAbsolute ? winRoot !== undefined ? winRoot : "/" : absRoot;
  while(segments.length > 0 && !isGlob(segments[0])){
    const seg = segments.shift();
    assert(seg !== undefined);
    fixedRoot = joinGlobs([
      fixedRoot,
      seg
    ], globOptions);
  }
  let fixedRootInfo;
  try {
    fixedRootInfo = await createWalkEntry(fixedRoot);
  } catch (error) {
    return throwUnlessNotFound(error);
  }
  async function* advanceMatch(walkInfo, globSegment) {
    if (!walkInfo.isDirectory) {
      return;
    } else if (globSegment === "..") {
      const parentPath = joinGlobs([
        walkInfo.path,
        ".."
      ], globOptions);
      try {
        if (shouldInclude(parentPath)) {
          return yield await createWalkEntry(parentPath);
        }
      } catch (error) {
        throwUnlessNotFound(error);
      }
      return;
    } else if (globSegment === "**") {
      return yield* walk(walkInfo.path, {
        skip: excludePatterns,
        maxDepth: globstar ? Infinity : 1,
        followSymlinks,
        canonicalize
      });
    }
    const globPattern = globToRegExp(globSegment, globOptions);
    for await (const walkEntry of walk(walkInfo.path, {
      maxDepth: 1,
      skip: excludePatterns,
      followSymlinks
    })){
      if (walkEntry.path !== walkInfo.path && walkEntry.name.match(globPattern)) {
        yield walkEntry;
      }
    }
  }
  let currentMatches = [
    fixedRootInfo
  ];
  for (const segment of segments){
    // Advancing the list of current matches may introduce duplicates, so we
    // pass everything through this Map.
    const nextMatchMap = new Map();
    await Promise.all(currentMatches.map(async (currentMatch)=>{
      for await (const nextMatch of advanceMatch(currentMatch, segment)){
        nextMatchMap.set(nextMatch.path, nextMatch);
      }
    }));
    currentMatches = [
      ...nextMatchMap.values()
    ].sort(comparePath);
  }
  if (hasTrailingSep) {
    currentMatches = currentMatches.filter((entry)=>entry.isDirectory);
  }
  if (!includeDirs) {
    currentMatches = currentMatches.filter((entry)=>!entry.isDirectory);
  }
  yield* currentMatches;
}
/**
 * Returns an iterator that yields each file path matching the given glob
 * pattern. The file paths are relative to the provided `root` directory.
 * If `root` is not provided, the current working directory is used.
 * The `root` directory is not included in the yielded file paths.
 *
 * Requires the `--allow-read` flag.
 *
 * @param glob The glob pattern to expand.
 * @param options Additional options for the expansion.
 * @returns An iterator that yields each walk entry matching the glob pattern.
 *
 * @example Basic usage
 *
 * File structure:
 * ```
 * folder
 * ├── script.ts
 * └── foo.ts
 * ```
 *
 * ```ts
 * // script.ts
 * import { expandGlobSync } from "https://deno.land/std@$STD_VERSION/fs/expand_glob.ts";
 *
 * const entries = [];
 * for (const entry of expandGlobSync("*.ts")) {
 *   entries.push(entry);
 * }
 *
 * entries[0]!.path; // "/Users/user/folder/script.ts"
 * entries[0]!.name; // "script.ts"
 * entries[0]!.isFile; // false
 * entries[0]!.isDirectory; // true
 * entries[0]!.isSymlink; // false
 *
 * entries[1]!.path; // "/Users/user/folder/foo.ts"
 * entries[1]!.name; // "foo.ts"
 * entries[1]!.isFile; // true
 * entries[1]!.isDirectory; // false
 * entries[1]!.isSymlink; // false
 * ```
 */ export function* expandGlobSync(glob, { root, exclude = [], includeDirs = true, extended = true, globstar = true, caseInsensitive, followSymlinks, canonicalize } = {}) {
  const { segments, isAbsolute: isGlobAbsolute, hasTrailingSep, winRoot } = split(toPathString(glob));
  root ??= isGlobAbsolute ? winRoot ?? "/" : Deno.cwd();
  const globOptions = {
    extended,
    globstar,
    caseInsensitive
  };
  const absRoot = isGlobAbsolute ? root : resolve(root); // root is always string here
  const resolveFromRoot = (path)=>resolve(absRoot, path);
  const excludePatterns = exclude.map(resolveFromRoot).map((s)=>globToRegExp(s, globOptions));
  const shouldInclude = (path)=>!excludePatterns.some((p)=>!!path.match(p));
  let fixedRoot = isGlobAbsolute ? winRoot !== undefined ? winRoot : "/" : absRoot;
  while(segments.length > 0 && !isGlob(segments[0])){
    const seg = segments.shift();
    assert(seg !== undefined);
    fixedRoot = joinGlobs([
      fixedRoot,
      seg
    ], globOptions);
  }
  let fixedRootInfo;
  try {
    fixedRootInfo = createWalkEntrySync(fixedRoot);
  } catch (error) {
    return throwUnlessNotFound(error);
  }
  function* advanceMatch(walkInfo, globSegment) {
    if (!walkInfo.isDirectory) {
      return;
    } else if (globSegment === "..") {
      const parentPath = joinGlobs([
        walkInfo.path,
        ".."
      ], globOptions);
      try {
        if (shouldInclude(parentPath)) {
          return yield createWalkEntrySync(parentPath);
        }
      } catch (error) {
        throwUnlessNotFound(error);
      }
      return;
    } else if (globSegment === "**") {
      return yield* walkSync(walkInfo.path, {
        skip: excludePatterns,
        maxDepth: globstar ? Infinity : 1,
        followSymlinks,
        canonicalize
      });
    }
    const globPattern = globToRegExp(globSegment, globOptions);
    for (const walkEntry of walkSync(walkInfo.path, {
      maxDepth: 1,
      skip: excludePatterns,
      followSymlinks
    })){
      if (walkEntry.path !== walkInfo.path && walkEntry.name.match(globPattern)) {
        yield walkEntry;
      }
    }
  }
  let currentMatches = [
    fixedRootInfo
  ];
  for (const segment of segments){
    // Advancing the list of current matches may introduce duplicates, so we
    // pass everything through this Map.
    const nextMatchMap = new Map();
    for (const currentMatch of currentMatches){
      for (const nextMatch of advanceMatch(currentMatch, segment)){
        nextMatchMap.set(nextMatch.path, nextMatch);
      }
    }
    currentMatches = [
      ...nextMatchMap.values()
    ].sort(comparePath);
  }
  if (hasTrailingSep) {
    currentMatches = currentMatches.filter((entry)=>entry.isDirectory);
  }
  if (!includeDirs) {
    currentMatches = currentMatches.filter((entry)=>!entry.isDirectory);
  }
  yield* currentMatches;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjIyNC4wL2ZzL2V4cGFuZF9nbG9iLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIENvcHlyaWdodCAyMDE4LTIwMjQgdGhlIERlbm8gYXV0aG9ycy4gQWxsIHJpZ2h0cyByZXNlcnZlZC4gTUlUIGxpY2Vuc2UuXG5pbXBvcnQgeyB0eXBlIEdsb2JPcHRpb25zLCBnbG9iVG9SZWdFeHAgfSBmcm9tIFwiLi4vcGF0aC9nbG9iX3RvX3JlZ2V4cC50c1wiO1xuaW1wb3J0IHsgam9pbkdsb2JzIH0gZnJvbSBcIi4uL3BhdGgvam9pbl9nbG9icy50c1wiO1xuaW1wb3J0IHsgaXNHbG9iIH0gZnJvbSBcIi4uL3BhdGgvaXNfZ2xvYi50c1wiO1xuaW1wb3J0IHsgaXNBYnNvbHV0ZSB9IGZyb20gXCIuLi9wYXRoL2lzX2Fic29sdXRlLnRzXCI7XG5pbXBvcnQgeyByZXNvbHZlIH0gZnJvbSBcIi4uL3BhdGgvcmVzb2x2ZS50c1wiO1xuaW1wb3J0IHsgU0VQQVJBVE9SX1BBVFRFUk4gfSBmcm9tIFwiLi4vcGF0aC9jb25zdGFudHMudHNcIjtcbmltcG9ydCB7IHdhbGssIHdhbGtTeW5jIH0gZnJvbSBcIi4vd2Fsay50c1wiO1xuaW1wb3J0IHsgYXNzZXJ0IH0gZnJvbSBcIi4uL2Fzc2VydC9hc3NlcnQudHNcIjtcbmltcG9ydCB7IHRvUGF0aFN0cmluZyB9IGZyb20gXCIuL190b19wYXRoX3N0cmluZy50c1wiO1xuaW1wb3J0IHtcbiAgY3JlYXRlV2Fsa0VudHJ5LFxuICBjcmVhdGVXYWxrRW50cnlTeW5jLFxuICB0eXBlIFdhbGtFbnRyeSxcbn0gZnJvbSBcIi4vX2NyZWF0ZV93YWxrX2VudHJ5LnRzXCI7XG5cbmV4cG9ydCB0eXBlIHsgR2xvYk9wdGlvbnMsIFdhbGtFbnRyeSB9O1xuXG5jb25zdCBpc1dpbmRvd3MgPSBEZW5vLmJ1aWxkLm9zID09PSBcIndpbmRvd3NcIjtcblxuLyoqIE9wdGlvbnMgZm9yIHtAbGlua2NvZGUgZXhwYW5kR2xvYn0gYW5kIHtAbGlua2NvZGUgZXhwYW5kR2xvYlN5bmN9LiAqL1xuZXhwb3J0IGludGVyZmFjZSBFeHBhbmRHbG9iT3B0aW9ucyBleHRlbmRzIE9taXQ8R2xvYk9wdGlvbnMsIFwib3NcIj4ge1xuICAvKiogRmlsZSBwYXRoIHdoZXJlIHRvIGV4cGFuZCBmcm9tLiAqL1xuICByb290Pzogc3RyaW5nO1xuICAvKiogTGlzdCBvZiBnbG9iIHBhdHRlcm5zIHRvIGJlIGV4Y2x1ZGVkIGZyb20gdGhlIGV4cGFuc2lvbi4gKi9cbiAgZXhjbHVkZT86IHN0cmluZ1tdO1xuICAvKipcbiAgICogV2hldGhlciB0byBpbmNsdWRlIGRpcmVjdG9yaWVzIGluIGVudHJpZXMuXG4gICAqXG4gICAqIEBkZWZhdWx0IHt0cnVlfVxuICAgKi9cbiAgaW5jbHVkZURpcnM/OiBib29sZWFuO1xuICAvKipcbiAgICogV2hldGhlciB0byBmb2xsb3cgc3ltYm9saWMgbGlua3MuXG4gICAqXG4gICAqIEBkZWZhdWx0IHtmYWxzZX1cbiAgICovXG4gIGZvbGxvd1N5bWxpbmtzPzogYm9vbGVhbjtcbiAgLyoqXG4gICAqIEluZGljYXRlcyB3aGV0aGVyIHRoZSBmb2xsb3dlZCBzeW1saW5rJ3MgcGF0aCBzaG91bGQgYmUgY2Fub25pY2FsaXplZC5cbiAgICogVGhpcyBvcHRpb24gd29ya3Mgb25seSBpZiBgZm9sbG93U3ltbGlua3NgIGlzIG5vdCBgZmFsc2VgLlxuICAgKlxuICAgKiBAZGVmYXVsdCB7dHJ1ZX1cbiAgICovXG4gIGNhbm9uaWNhbGl6ZT86IGJvb2xlYW47XG59XG5cbmludGVyZmFjZSBTcGxpdFBhdGgge1xuICBzZWdtZW50czogc3RyaW5nW107XG4gIGlzQWJzb2x1dGU6IGJvb2xlYW47XG4gIGhhc1RyYWlsaW5nU2VwOiBib29sZWFuO1xuICAvLyBEZWZpbmVkIGZvciBhbnkgYWJzb2x1dGUgV2luZG93cyBwYXRoLlxuICB3aW5Sb290Pzogc3RyaW5nO1xufVxuXG5mdW5jdGlvbiBzcGxpdChwYXRoOiBzdHJpbmcpOiBTcGxpdFBhdGgge1xuICBjb25zdCBzID0gU0VQQVJBVE9SX1BBVFRFUk4uc291cmNlO1xuICBjb25zdCBzZWdtZW50cyA9IHBhdGhcbiAgICAucmVwbGFjZShuZXcgUmVnRXhwKGBeJHtzfXwke3N9JGAsIFwiZ1wiKSwgXCJcIilcbiAgICAuc3BsaXQoU0VQQVJBVE9SX1BBVFRFUk4pO1xuICBjb25zdCBpc0Fic29sdXRlXyA9IGlzQWJzb2x1dGUocGF0aCk7XG4gIHJldHVybiB7XG4gICAgc2VnbWVudHMsXG4gICAgaXNBYnNvbHV0ZTogaXNBYnNvbHV0ZV8sXG4gICAgaGFzVHJhaWxpbmdTZXA6ICEhcGF0aC5tYXRjaChuZXcgUmVnRXhwKGAke3N9JGApKSxcbiAgICB3aW5Sb290OiBpc1dpbmRvd3MgJiYgaXNBYnNvbHV0ZV8gPyBzZWdtZW50cy5zaGlmdCgpIDogdW5kZWZpbmVkLFxuICB9O1xufVxuXG5mdW5jdGlvbiB0aHJvd1VubGVzc05vdEZvdW5kKGVycm9yOiB1bmtub3duKSB7XG4gIGlmICghKGVycm9yIGluc3RhbmNlb2YgRGVuby5lcnJvcnMuTm90Rm91bmQpKSB7XG4gICAgdGhyb3cgZXJyb3I7XG4gIH1cbn1cblxuZnVuY3Rpb24gY29tcGFyZVBhdGgoYTogV2Fsa0VudHJ5LCBiOiBXYWxrRW50cnkpOiBudW1iZXIge1xuICBpZiAoYS5wYXRoIDwgYi5wYXRoKSByZXR1cm4gLTE7XG4gIGlmIChhLnBhdGggPiBiLnBhdGgpIHJldHVybiAxO1xuICByZXR1cm4gMDtcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGFuIGFzeW5jIGl0ZXJhdG9yIHRoYXQgeWllbGRzIGVhY2ggZmlsZSBwYXRoIG1hdGNoaW5nIHRoZSBnaXZlbiBnbG9iXG4gKiBwYXR0ZXJuLiBUaGUgZmlsZSBwYXRocyBhcmUgcmVsYXRpdmUgdG8gdGhlIHByb3ZpZGVkIGByb290YCBkaXJlY3RvcnkuXG4gKiBJZiBgcm9vdGAgaXMgbm90IHByb3ZpZGVkLCB0aGUgY3VycmVudCB3b3JraW5nIGRpcmVjdG9yeSBpcyB1c2VkLlxuICogVGhlIGByb290YCBkaXJlY3RvcnkgaXMgbm90IGluY2x1ZGVkIGluIHRoZSB5aWVsZGVkIGZpbGUgcGF0aHMuXG4gKlxuICogUmVxdWlyZXMgdGhlIGAtLWFsbG93LXJlYWRgIGZsYWcuXG4gKlxuICogQHBhcmFtIGdsb2IgVGhlIGdsb2IgcGF0dGVybiB0byBleHBhbmQuXG4gKiBAcGFyYW0gb3B0aW9ucyBBZGRpdGlvbmFsIG9wdGlvbnMgZm9yIHRoZSBleHBhbnNpb24uXG4gKiBAcmV0dXJucyBBbiBhc3luYyBpdGVyYXRvciB0aGF0IHlpZWxkcyBlYWNoIHdhbGsgZW50cnkgbWF0Y2hpbmcgdGhlIGdsb2JcbiAqIHBhdHRlcm4uXG4gKlxuICogQGV4YW1wbGUgQmFzaWMgdXNhZ2VcbiAqXG4gKiBGaWxlIHN0cnVjdHVyZTpcbiAqIGBgYFxuICogZm9sZGVyXG4gKiDilJzilIDilIAgc2NyaXB0LnRzXG4gKiDilJTilIDilIAgZm9vLnRzXG4gKiBgYGBcbiAqXG4gKiBgYGB0c1xuICogLy8gc2NyaXB0LnRzXG4gKiBpbXBvcnQgeyBleHBhbmRHbG9iIH0gZnJvbSBcImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAkU1REX1ZFUlNJT04vZnMvZXhwYW5kX2dsb2IudHNcIjtcbiAqXG4gKiBjb25zdCBlbnRyaWVzID0gW107XG4gKiBmb3IgYXdhaXQgKGNvbnN0IGVudHJ5IG9mIGV4cGFuZEdsb2IoXCIqLnRzXCIpKSB7XG4gKiAgIGVudHJpZXMucHVzaChlbnRyeSk7XG4gKiB9XG4gKlxuICogZW50cmllc1swXSEucGF0aDsgLy8gXCIvVXNlcnMvdXNlci9mb2xkZXIvc2NyaXB0LnRzXCJcbiAqIGVudHJpZXNbMF0hLm5hbWU7IC8vIFwic2NyaXB0LnRzXCJcbiAqIGVudHJpZXNbMF0hLmlzRmlsZTsgLy8gZmFsc2VcbiAqIGVudHJpZXNbMF0hLmlzRGlyZWN0b3J5OyAvLyB0cnVlXG4gKiBlbnRyaWVzWzBdIS5pc1N5bWxpbms7IC8vIGZhbHNlXG4gKlxuICogZW50cmllc1sxXSEucGF0aDsgLy8gXCIvVXNlcnMvdXNlci9mb2xkZXIvZm9vLnRzXCJcbiAqIGVudHJpZXNbMV0hLm5hbWU7IC8vIFwiZm9vLnRzXCJcbiAqIGVudHJpZXNbMV0hLmlzRmlsZTsgLy8gdHJ1ZVxuICogZW50cmllc1sxXSEuaXNEaXJlY3Rvcnk7IC8vIGZhbHNlXG4gKiBlbnRyaWVzWzFdIS5pc1N5bWxpbms7IC8vIGZhbHNlXG4gKiBgYGBcbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uKiBleHBhbmRHbG9iKFxuICBnbG9iOiBzdHJpbmcgfCBVUkwsXG4gIHtcbiAgICByb290LFxuICAgIGV4Y2x1ZGUgPSBbXSxcbiAgICBpbmNsdWRlRGlycyA9IHRydWUsXG4gICAgZXh0ZW5kZWQgPSB0cnVlLFxuICAgIGdsb2JzdGFyID0gdHJ1ZSxcbiAgICBjYXNlSW5zZW5zaXRpdmUsXG4gICAgZm9sbG93U3ltbGlua3MsXG4gICAgY2Fub25pY2FsaXplLFxuICB9OiBFeHBhbmRHbG9iT3B0aW9ucyA9IHt9LFxuKTogQXN5bmNJdGVyYWJsZUl0ZXJhdG9yPFdhbGtFbnRyeT4ge1xuICBjb25zdCB7XG4gICAgc2VnbWVudHMsXG4gICAgaXNBYnNvbHV0ZTogaXNHbG9iQWJzb2x1dGUsXG4gICAgaGFzVHJhaWxpbmdTZXAsXG4gICAgd2luUm9vdCxcbiAgfSA9IHNwbGl0KHRvUGF0aFN0cmluZyhnbG9iKSk7XG4gIHJvb3QgPz89IGlzR2xvYkFic29sdXRlID8gd2luUm9vdCA/PyBcIi9cIiA6IERlbm8uY3dkKCk7XG5cbiAgY29uc3QgZ2xvYk9wdGlvbnM6IEdsb2JPcHRpb25zID0geyBleHRlbmRlZCwgZ2xvYnN0YXIsIGNhc2VJbnNlbnNpdGl2ZSB9O1xuICBjb25zdCBhYnNSb290ID0gaXNHbG9iQWJzb2x1dGUgPyByb290IDogcmVzb2x2ZShyb290ISk7IC8vIHJvb3QgaXMgYWx3YXlzIHN0cmluZyBoZXJlXG4gIGNvbnN0IHJlc29sdmVGcm9tUm9vdCA9IChwYXRoOiBzdHJpbmcpOiBzdHJpbmcgPT4gcmVzb2x2ZShhYnNSb290LCBwYXRoKTtcbiAgY29uc3QgZXhjbHVkZVBhdHRlcm5zID0gZXhjbHVkZVxuICAgIC5tYXAocmVzb2x2ZUZyb21Sb290KVxuICAgIC5tYXAoKHM6IHN0cmluZyk6IFJlZ0V4cCA9PiBnbG9iVG9SZWdFeHAocywgZ2xvYk9wdGlvbnMpKTtcbiAgY29uc3Qgc2hvdWxkSW5jbHVkZSA9IChwYXRoOiBzdHJpbmcpOiBib29sZWFuID0+XG4gICAgIWV4Y2x1ZGVQYXR0ZXJucy5zb21lKChwOiBSZWdFeHApOiBib29sZWFuID0+ICEhcGF0aC5tYXRjaChwKSk7XG5cbiAgbGV0IGZpeGVkUm9vdCA9IGlzR2xvYkFic29sdXRlXG4gICAgPyB3aW5Sb290ICE9PSB1bmRlZmluZWQgPyB3aW5Sb290IDogXCIvXCJcbiAgICA6IGFic1Jvb3Q7XG4gIHdoaWxlIChzZWdtZW50cy5sZW5ndGggPiAwICYmICFpc0dsb2Ioc2VnbWVudHNbMF0hKSkge1xuICAgIGNvbnN0IHNlZyA9IHNlZ21lbnRzLnNoaWZ0KCk7XG4gICAgYXNzZXJ0KHNlZyAhPT0gdW5kZWZpbmVkKTtcbiAgICBmaXhlZFJvb3QgPSBqb2luR2xvYnMoW2ZpeGVkUm9vdCwgc2VnXSwgZ2xvYk9wdGlvbnMpO1xuICB9XG5cbiAgbGV0IGZpeGVkUm9vdEluZm86IFdhbGtFbnRyeTtcbiAgdHJ5IHtcbiAgICBmaXhlZFJvb3RJbmZvID0gYXdhaXQgY3JlYXRlV2Fsa0VudHJ5KGZpeGVkUm9vdCk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgcmV0dXJuIHRocm93VW5sZXNzTm90Rm91bmQoZXJyb3IpO1xuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24qIGFkdmFuY2VNYXRjaChcbiAgICB3YWxrSW5mbzogV2Fsa0VudHJ5LFxuICAgIGdsb2JTZWdtZW50OiBzdHJpbmcsXG4gICk6IEFzeW5jSXRlcmFibGVJdGVyYXRvcjxXYWxrRW50cnk+IHtcbiAgICBpZiAoIXdhbGtJbmZvLmlzRGlyZWN0b3J5KSB7XG4gICAgICByZXR1cm47XG4gICAgfSBlbHNlIGlmIChnbG9iU2VnbWVudCA9PT0gXCIuLlwiKSB7XG4gICAgICBjb25zdCBwYXJlbnRQYXRoID0gam9pbkdsb2JzKFt3YWxrSW5mby5wYXRoLCBcIi4uXCJdLCBnbG9iT3B0aW9ucyk7XG4gICAgICB0cnkge1xuICAgICAgICBpZiAoc2hvdWxkSW5jbHVkZShwYXJlbnRQYXRoKSkge1xuICAgICAgICAgIHJldHVybiB5aWVsZCBhd2FpdCBjcmVhdGVXYWxrRW50cnkocGFyZW50UGF0aCk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93VW5sZXNzTm90Rm91bmQoZXJyb3IpO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH0gZWxzZSBpZiAoZ2xvYlNlZ21lbnQgPT09IFwiKipcIikge1xuICAgICAgcmV0dXJuIHlpZWxkKiB3YWxrKHdhbGtJbmZvLnBhdGgsIHtcbiAgICAgICAgc2tpcDogZXhjbHVkZVBhdHRlcm5zLFxuICAgICAgICBtYXhEZXB0aDogZ2xvYnN0YXIgPyBJbmZpbml0eSA6IDEsXG4gICAgICAgIGZvbGxvd1N5bWxpbmtzLFxuICAgICAgICBjYW5vbmljYWxpemUsXG4gICAgICB9KTtcbiAgICB9XG4gICAgY29uc3QgZ2xvYlBhdHRlcm4gPSBnbG9iVG9SZWdFeHAoZ2xvYlNlZ21lbnQsIGdsb2JPcHRpb25zKTtcbiAgICBmb3IgYXdhaXQgKFxuICAgICAgY29uc3Qgd2Fsa0VudHJ5IG9mIHdhbGsod2Fsa0luZm8ucGF0aCwge1xuICAgICAgICBtYXhEZXB0aDogMSxcbiAgICAgICAgc2tpcDogZXhjbHVkZVBhdHRlcm5zLFxuICAgICAgICBmb2xsb3dTeW1saW5rcyxcbiAgICAgIH0pXG4gICAgKSB7XG4gICAgICBpZiAoXG4gICAgICAgIHdhbGtFbnRyeS5wYXRoICE9PSB3YWxrSW5mby5wYXRoICYmXG4gICAgICAgIHdhbGtFbnRyeS5uYW1lLm1hdGNoKGdsb2JQYXR0ZXJuKVxuICAgICAgKSB7XG4gICAgICAgIHlpZWxkIHdhbGtFbnRyeTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBsZXQgY3VycmVudE1hdGNoZXM6IFdhbGtFbnRyeVtdID0gW2ZpeGVkUm9vdEluZm9dO1xuICBmb3IgKGNvbnN0IHNlZ21lbnQgb2Ygc2VnbWVudHMpIHtcbiAgICAvLyBBZHZhbmNpbmcgdGhlIGxpc3Qgb2YgY3VycmVudCBtYXRjaGVzIG1heSBpbnRyb2R1Y2UgZHVwbGljYXRlcywgc28gd2VcbiAgICAvLyBwYXNzIGV2ZXJ5dGhpbmcgdGhyb3VnaCB0aGlzIE1hcC5cbiAgICBjb25zdCBuZXh0TWF0Y2hNYXA6IE1hcDxzdHJpbmcsIFdhbGtFbnRyeT4gPSBuZXcgTWFwKCk7XG4gICAgYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICBjdXJyZW50TWF0Y2hlcy5tYXAoYXN5bmMgKGN1cnJlbnRNYXRjaCkgPT4ge1xuICAgICAgICBmb3IgYXdhaXQgKGNvbnN0IG5leHRNYXRjaCBvZiBhZHZhbmNlTWF0Y2goY3VycmVudE1hdGNoLCBzZWdtZW50KSkge1xuICAgICAgICAgIG5leHRNYXRjaE1hcC5zZXQobmV4dE1hdGNoLnBhdGgsIG5leHRNYXRjaCk7XG4gICAgICAgIH1cbiAgICAgIH0pLFxuICAgICk7XG4gICAgY3VycmVudE1hdGNoZXMgPSBbLi4ubmV4dE1hdGNoTWFwLnZhbHVlcygpXS5zb3J0KGNvbXBhcmVQYXRoKTtcbiAgfVxuXG4gIGlmIChoYXNUcmFpbGluZ1NlcCkge1xuICAgIGN1cnJlbnRNYXRjaGVzID0gY3VycmVudE1hdGNoZXMuZmlsdGVyKFxuICAgICAgKGVudHJ5OiBXYWxrRW50cnkpOiBib29sZWFuID0+IGVudHJ5LmlzRGlyZWN0b3J5LFxuICAgICk7XG4gIH1cbiAgaWYgKCFpbmNsdWRlRGlycykge1xuICAgIGN1cnJlbnRNYXRjaGVzID0gY3VycmVudE1hdGNoZXMuZmlsdGVyKFxuICAgICAgKGVudHJ5OiBXYWxrRW50cnkpOiBib29sZWFuID0+ICFlbnRyeS5pc0RpcmVjdG9yeSxcbiAgICApO1xuICB9XG4gIHlpZWxkKiBjdXJyZW50TWF0Y2hlcztcbn1cblxuLyoqXG4gKiBSZXR1cm5zIGFuIGl0ZXJhdG9yIHRoYXQgeWllbGRzIGVhY2ggZmlsZSBwYXRoIG1hdGNoaW5nIHRoZSBnaXZlbiBnbG9iXG4gKiBwYXR0ZXJuLiBUaGUgZmlsZSBwYXRocyBhcmUgcmVsYXRpdmUgdG8gdGhlIHByb3ZpZGVkIGByb290YCBkaXJlY3RvcnkuXG4gKiBJZiBgcm9vdGAgaXMgbm90IHByb3ZpZGVkLCB0aGUgY3VycmVudCB3b3JraW5nIGRpcmVjdG9yeSBpcyB1c2VkLlxuICogVGhlIGByb290YCBkaXJlY3RvcnkgaXMgbm90IGluY2x1ZGVkIGluIHRoZSB5aWVsZGVkIGZpbGUgcGF0aHMuXG4gKlxuICogUmVxdWlyZXMgdGhlIGAtLWFsbG93LXJlYWRgIGZsYWcuXG4gKlxuICogQHBhcmFtIGdsb2IgVGhlIGdsb2IgcGF0dGVybiB0byBleHBhbmQuXG4gKiBAcGFyYW0gb3B0aW9ucyBBZGRpdGlvbmFsIG9wdGlvbnMgZm9yIHRoZSBleHBhbnNpb24uXG4gKiBAcmV0dXJucyBBbiBpdGVyYXRvciB0aGF0IHlpZWxkcyBlYWNoIHdhbGsgZW50cnkgbWF0Y2hpbmcgdGhlIGdsb2IgcGF0dGVybi5cbiAqXG4gKiBAZXhhbXBsZSBCYXNpYyB1c2FnZVxuICpcbiAqIEZpbGUgc3RydWN0dXJlOlxuICogYGBgXG4gKiBmb2xkZXJcbiAqIOKUnOKUgOKUgCBzY3JpcHQudHNcbiAqIOKUlOKUgOKUgCBmb28udHNcbiAqIGBgYFxuICpcbiAqIGBgYHRzXG4gKiAvLyBzY3JpcHQudHNcbiAqIGltcG9ydCB7IGV4cGFuZEdsb2JTeW5jIH0gZnJvbSBcImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAkU1REX1ZFUlNJT04vZnMvZXhwYW5kX2dsb2IudHNcIjtcbiAqXG4gKiBjb25zdCBlbnRyaWVzID0gW107XG4gKiBmb3IgKGNvbnN0IGVudHJ5IG9mIGV4cGFuZEdsb2JTeW5jKFwiKi50c1wiKSkge1xuICogICBlbnRyaWVzLnB1c2goZW50cnkpO1xuICogfVxuICpcbiAqIGVudHJpZXNbMF0hLnBhdGg7IC8vIFwiL1VzZXJzL3VzZXIvZm9sZGVyL3NjcmlwdC50c1wiXG4gKiBlbnRyaWVzWzBdIS5uYW1lOyAvLyBcInNjcmlwdC50c1wiXG4gKiBlbnRyaWVzWzBdIS5pc0ZpbGU7IC8vIGZhbHNlXG4gKiBlbnRyaWVzWzBdIS5pc0RpcmVjdG9yeTsgLy8gdHJ1ZVxuICogZW50cmllc1swXSEuaXNTeW1saW5rOyAvLyBmYWxzZVxuICpcbiAqIGVudHJpZXNbMV0hLnBhdGg7IC8vIFwiL1VzZXJzL3VzZXIvZm9sZGVyL2Zvby50c1wiXG4gKiBlbnRyaWVzWzFdIS5uYW1lOyAvLyBcImZvby50c1wiXG4gKiBlbnRyaWVzWzFdIS5pc0ZpbGU7IC8vIHRydWVcbiAqIGVudHJpZXNbMV0hLmlzRGlyZWN0b3J5OyAvLyBmYWxzZVxuICogZW50cmllc1sxXSEuaXNTeW1saW5rOyAvLyBmYWxzZVxuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiogZXhwYW5kR2xvYlN5bmMoXG4gIGdsb2I6IHN0cmluZyB8IFVSTCxcbiAge1xuICAgIHJvb3QsXG4gICAgZXhjbHVkZSA9IFtdLFxuICAgIGluY2x1ZGVEaXJzID0gdHJ1ZSxcbiAgICBleHRlbmRlZCA9IHRydWUsXG4gICAgZ2xvYnN0YXIgPSB0cnVlLFxuICAgIGNhc2VJbnNlbnNpdGl2ZSxcbiAgICBmb2xsb3dTeW1saW5rcyxcbiAgICBjYW5vbmljYWxpemUsXG4gIH06IEV4cGFuZEdsb2JPcHRpb25zID0ge30sXG4pOiBJdGVyYWJsZUl0ZXJhdG9yPFdhbGtFbnRyeT4ge1xuICBjb25zdCB7XG4gICAgc2VnbWVudHMsXG4gICAgaXNBYnNvbHV0ZTogaXNHbG9iQWJzb2x1dGUsXG4gICAgaGFzVHJhaWxpbmdTZXAsXG4gICAgd2luUm9vdCxcbiAgfSA9IHNwbGl0KHRvUGF0aFN0cmluZyhnbG9iKSk7XG4gIHJvb3QgPz89IGlzR2xvYkFic29sdXRlID8gd2luUm9vdCA/PyBcIi9cIiA6IERlbm8uY3dkKCk7XG5cbiAgY29uc3QgZ2xvYk9wdGlvbnM6IEdsb2JPcHRpb25zID0geyBleHRlbmRlZCwgZ2xvYnN0YXIsIGNhc2VJbnNlbnNpdGl2ZSB9O1xuICBjb25zdCBhYnNSb290ID0gaXNHbG9iQWJzb2x1dGUgPyByb290IDogcmVzb2x2ZShyb290ISk7IC8vIHJvb3QgaXMgYWx3YXlzIHN0cmluZyBoZXJlXG4gIGNvbnN0IHJlc29sdmVGcm9tUm9vdCA9IChwYXRoOiBzdHJpbmcpOiBzdHJpbmcgPT4gcmVzb2x2ZShhYnNSb290LCBwYXRoKTtcbiAgY29uc3QgZXhjbHVkZVBhdHRlcm5zID0gZXhjbHVkZVxuICAgIC5tYXAocmVzb2x2ZUZyb21Sb290KVxuICAgIC5tYXAoKHM6IHN0cmluZyk6IFJlZ0V4cCA9PiBnbG9iVG9SZWdFeHAocywgZ2xvYk9wdGlvbnMpKTtcbiAgY29uc3Qgc2hvdWxkSW5jbHVkZSA9IChwYXRoOiBzdHJpbmcpOiBib29sZWFuID0+XG4gICAgIWV4Y2x1ZGVQYXR0ZXJucy5zb21lKChwOiBSZWdFeHApOiBib29sZWFuID0+ICEhcGF0aC5tYXRjaChwKSk7XG5cbiAgbGV0IGZpeGVkUm9vdCA9IGlzR2xvYkFic29sdXRlXG4gICAgPyB3aW5Sb290ICE9PSB1bmRlZmluZWQgPyB3aW5Sb290IDogXCIvXCJcbiAgICA6IGFic1Jvb3Q7XG4gIHdoaWxlIChzZWdtZW50cy5sZW5ndGggPiAwICYmICFpc0dsb2Ioc2VnbWVudHNbMF0hKSkge1xuICAgIGNvbnN0IHNlZyA9IHNlZ21lbnRzLnNoaWZ0KCk7XG4gICAgYXNzZXJ0KHNlZyAhPT0gdW5kZWZpbmVkKTtcbiAgICBmaXhlZFJvb3QgPSBqb2luR2xvYnMoW2ZpeGVkUm9vdCwgc2VnXSwgZ2xvYk9wdGlvbnMpO1xuICB9XG5cbiAgbGV0IGZpeGVkUm9vdEluZm86IFdhbGtFbnRyeTtcbiAgdHJ5IHtcbiAgICBmaXhlZFJvb3RJbmZvID0gY3JlYXRlV2Fsa0VudHJ5U3luYyhmaXhlZFJvb3QpO1xuICB9IGNhdGNoIChlcnJvcikge1xuICAgIHJldHVybiB0aHJvd1VubGVzc05vdEZvdW5kKGVycm9yKTtcbiAgfVxuXG4gIGZ1bmN0aW9uKiBhZHZhbmNlTWF0Y2goXG4gICAgd2Fsa0luZm86IFdhbGtFbnRyeSxcbiAgICBnbG9iU2VnbWVudDogc3RyaW5nLFxuICApOiBJdGVyYWJsZUl0ZXJhdG9yPFdhbGtFbnRyeT4ge1xuICAgIGlmICghd2Fsa0luZm8uaXNEaXJlY3RvcnkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9IGVsc2UgaWYgKGdsb2JTZWdtZW50ID09PSBcIi4uXCIpIHtcbiAgICAgIGNvbnN0IHBhcmVudFBhdGggPSBqb2luR2xvYnMoW3dhbGtJbmZvLnBhdGgsIFwiLi5cIl0sIGdsb2JPcHRpb25zKTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGlmIChzaG91bGRJbmNsdWRlKHBhcmVudFBhdGgpKSB7XG4gICAgICAgICAgcmV0dXJuIHlpZWxkIGNyZWF0ZVdhbGtFbnRyeVN5bmMocGFyZW50UGF0aCk7XG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93VW5sZXNzTm90Rm91bmQoZXJyb3IpO1xuICAgICAgfVxuICAgICAgcmV0dXJuO1xuICAgIH0gZWxzZSBpZiAoZ2xvYlNlZ21lbnQgPT09IFwiKipcIikge1xuICAgICAgcmV0dXJuIHlpZWxkKiB3YWxrU3luYyh3YWxrSW5mby5wYXRoLCB7XG4gICAgICAgIHNraXA6IGV4Y2x1ZGVQYXR0ZXJucyxcbiAgICAgICAgbWF4RGVwdGg6IGdsb2JzdGFyID8gSW5maW5pdHkgOiAxLFxuICAgICAgICBmb2xsb3dTeW1saW5rcyxcbiAgICAgICAgY2Fub25pY2FsaXplLFxuICAgICAgfSk7XG4gICAgfVxuICAgIGNvbnN0IGdsb2JQYXR0ZXJuID0gZ2xvYlRvUmVnRXhwKGdsb2JTZWdtZW50LCBnbG9iT3B0aW9ucyk7XG4gICAgZm9yIChcbiAgICAgIGNvbnN0IHdhbGtFbnRyeSBvZiB3YWxrU3luYyh3YWxrSW5mby5wYXRoLCB7XG4gICAgICAgIG1heERlcHRoOiAxLFxuICAgICAgICBza2lwOiBleGNsdWRlUGF0dGVybnMsXG4gICAgICAgIGZvbGxvd1N5bWxpbmtzLFxuICAgICAgfSlcbiAgICApIHtcbiAgICAgIGlmIChcbiAgICAgICAgd2Fsa0VudHJ5LnBhdGggIT09IHdhbGtJbmZvLnBhdGggJiZcbiAgICAgICAgd2Fsa0VudHJ5Lm5hbWUubWF0Y2goZ2xvYlBhdHRlcm4pXG4gICAgICApIHtcbiAgICAgICAgeWllbGQgd2Fsa0VudHJ5O1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGxldCBjdXJyZW50TWF0Y2hlczogV2Fsa0VudHJ5W10gPSBbZml4ZWRSb290SW5mb107XG4gIGZvciAoY29uc3Qgc2VnbWVudCBvZiBzZWdtZW50cykge1xuICAgIC8vIEFkdmFuY2luZyB0aGUgbGlzdCBvZiBjdXJyZW50IG1hdGNoZXMgbWF5IGludHJvZHVjZSBkdXBsaWNhdGVzLCBzbyB3ZVxuICAgIC8vIHBhc3MgZXZlcnl0aGluZyB0aHJvdWdoIHRoaXMgTWFwLlxuICAgIGNvbnN0IG5leHRNYXRjaE1hcDogTWFwPHN0cmluZywgV2Fsa0VudHJ5PiA9IG5ldyBNYXAoKTtcbiAgICBmb3IgKGNvbnN0IGN1cnJlbnRNYXRjaCBvZiBjdXJyZW50TWF0Y2hlcykge1xuICAgICAgZm9yIChjb25zdCBuZXh0TWF0Y2ggb2YgYWR2YW5jZU1hdGNoKGN1cnJlbnRNYXRjaCwgc2VnbWVudCkpIHtcbiAgICAgICAgbmV4dE1hdGNoTWFwLnNldChuZXh0TWF0Y2gucGF0aCwgbmV4dE1hdGNoKTtcbiAgICAgIH1cbiAgICB9XG4gICAgY3VycmVudE1hdGNoZXMgPSBbLi4ubmV4dE1hdGNoTWFwLnZhbHVlcygpXS5zb3J0KGNvbXBhcmVQYXRoKTtcbiAgfVxuXG4gIGlmIChoYXNUcmFpbGluZ1NlcCkge1xuICAgIGN1cnJlbnRNYXRjaGVzID0gY3VycmVudE1hdGNoZXMuZmlsdGVyKFxuICAgICAgKGVudHJ5OiBXYWxrRW50cnkpOiBib29sZWFuID0+IGVudHJ5LmlzRGlyZWN0b3J5LFxuICAgICk7XG4gIH1cbiAgaWYgKCFpbmNsdWRlRGlycykge1xuICAgIGN1cnJlbnRNYXRjaGVzID0gY3VycmVudE1hdGNoZXMuZmlsdGVyKFxuICAgICAgKGVudHJ5OiBXYWxrRW50cnkpOiBib29sZWFuID0+ICFlbnRyeS5pc0RpcmVjdG9yeSxcbiAgICApO1xuICB9XG4gIHlpZWxkKiBjdXJyZW50TWF0Y2hlcztcbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSwwRUFBMEU7QUFDMUUsU0FBMkIsWUFBWSxRQUFRLDRCQUE0QjtBQUMzRSxTQUFTLFNBQVMsUUFBUSx3QkFBd0I7QUFDbEQsU0FBUyxNQUFNLFFBQVEscUJBQXFCO0FBQzVDLFNBQVMsVUFBVSxRQUFRLHlCQUF5QjtBQUNwRCxTQUFTLE9BQU8sUUFBUSxxQkFBcUI7QUFDN0MsU0FBUyxpQkFBaUIsUUFBUSx1QkFBdUI7QUFDekQsU0FBUyxJQUFJLEVBQUUsUUFBUSxRQUFRLFlBQVk7QUFDM0MsU0FBUyxNQUFNLFFBQVEsc0JBQXNCO0FBQzdDLFNBQVMsWUFBWSxRQUFRLHVCQUF1QjtBQUNwRCxTQUNFLGVBQWUsRUFDZixtQkFBbUIsUUFFZCwwQkFBMEI7QUFJakMsTUFBTSxZQUFZLEtBQUssS0FBSyxDQUFDLEVBQUUsS0FBSztBQXFDcEMsU0FBUyxNQUFNLElBQVk7RUFDekIsTUFBTSxJQUFJLGtCQUFrQixNQUFNO0VBQ2xDLE1BQU0sV0FBVyxLQUNkLE9BQU8sQ0FBQyxJQUFJLE9BQU8sQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsRUFBRSxNQUFNLElBQ3hDLEtBQUssQ0FBQztFQUNULE1BQU0sY0FBYyxXQUFXO0VBQy9CLE9BQU87SUFDTDtJQUNBLFlBQVk7SUFDWixnQkFBZ0IsQ0FBQyxDQUFDLEtBQUssS0FBSyxDQUFDLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0lBQy9DLFNBQVMsYUFBYSxjQUFjLFNBQVMsS0FBSyxLQUFLO0VBQ3pEO0FBQ0Y7QUFFQSxTQUFTLG9CQUFvQixLQUFjO0VBQ3pDLElBQUksQ0FBQyxDQUFDLGlCQUFpQixLQUFLLE1BQU0sQ0FBQyxRQUFRLEdBQUc7SUFDNUMsTUFBTTtFQUNSO0FBQ0Y7QUFFQSxTQUFTLFlBQVksQ0FBWSxFQUFFLENBQVk7RUFDN0MsSUFBSSxFQUFFLElBQUksR0FBRyxFQUFFLElBQUksRUFBRSxPQUFPLENBQUM7RUFDN0IsSUFBSSxFQUFFLElBQUksR0FBRyxFQUFFLElBQUksRUFBRSxPQUFPO0VBQzVCLE9BQU87QUFDVDtBQUVBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0NBMkNDLEdBQ0QsT0FBTyxnQkFBZ0IsV0FDckIsSUFBa0IsRUFDbEIsRUFDRSxJQUFJLEVBQ0osVUFBVSxFQUFFLEVBQ1osY0FBYyxJQUFJLEVBQ2xCLFdBQVcsSUFBSSxFQUNmLFdBQVcsSUFBSSxFQUNmLGVBQWUsRUFDZixjQUFjLEVBQ2QsWUFBWSxFQUNNLEdBQUcsQ0FBQyxDQUFDO0VBRXpCLE1BQU0sRUFDSixRQUFRLEVBQ1IsWUFBWSxjQUFjLEVBQzFCLGNBQWMsRUFDZCxPQUFPLEVBQ1IsR0FBRyxNQUFNLGFBQWE7RUFDdkIsU0FBUyxpQkFBaUIsV0FBVyxNQUFNLEtBQUssR0FBRztFQUVuRCxNQUFNLGNBQTJCO0lBQUU7SUFBVTtJQUFVO0VBQWdCO0VBQ3ZFLE1BQU0sVUFBVSxpQkFBaUIsT0FBTyxRQUFRLE9BQVEsNkJBQTZCO0VBQ3JGLE1BQU0sa0JBQWtCLENBQUMsT0FBeUIsUUFBUSxTQUFTO0VBQ25FLE1BQU0sa0JBQWtCLFFBQ3JCLEdBQUcsQ0FBQyxpQkFDSixHQUFHLENBQUMsQ0FBQyxJQUFzQixhQUFhLEdBQUc7RUFDOUMsTUFBTSxnQkFBZ0IsQ0FBQyxPQUNyQixDQUFDLGdCQUFnQixJQUFJLENBQUMsQ0FBQyxJQUF1QixDQUFDLENBQUMsS0FBSyxLQUFLLENBQUM7RUFFN0QsSUFBSSxZQUFZLGlCQUNaLFlBQVksWUFBWSxVQUFVLE1BQ2xDO0VBQ0osTUFBTyxTQUFTLE1BQU0sR0FBRyxLQUFLLENBQUMsT0FBTyxRQUFRLENBQUMsRUFBRSxFQUFJO0lBQ25ELE1BQU0sTUFBTSxTQUFTLEtBQUs7SUFDMUIsT0FBTyxRQUFRO0lBQ2YsWUFBWSxVQUFVO01BQUM7TUFBVztLQUFJLEVBQUU7RUFDMUM7RUFFQSxJQUFJO0VBQ0osSUFBSTtJQUNGLGdCQUFnQixNQUFNLGdCQUFnQjtFQUN4QyxFQUFFLE9BQU8sT0FBTztJQUNkLE9BQU8sb0JBQW9CO0VBQzdCO0VBRUEsZ0JBQWdCLGFBQ2QsUUFBbUIsRUFDbkIsV0FBbUI7SUFFbkIsSUFBSSxDQUFDLFNBQVMsV0FBVyxFQUFFO01BQ3pCO0lBQ0YsT0FBTyxJQUFJLGdCQUFnQixNQUFNO01BQy9CLE1BQU0sYUFBYSxVQUFVO1FBQUMsU0FBUyxJQUFJO1FBQUU7T0FBSyxFQUFFO01BQ3BELElBQUk7UUFDRixJQUFJLGNBQWMsYUFBYTtVQUM3QixPQUFPLE1BQU0sTUFBTSxnQkFBZ0I7UUFDckM7TUFDRixFQUFFLE9BQU8sT0FBTztRQUNkLG9CQUFvQjtNQUN0QjtNQUNBO0lBQ0YsT0FBTyxJQUFJLGdCQUFnQixNQUFNO01BQy9CLE9BQU8sT0FBTyxLQUFLLFNBQVMsSUFBSSxFQUFFO1FBQ2hDLE1BQU07UUFDTixVQUFVLFdBQVcsV0FBVztRQUNoQztRQUNBO01BQ0Y7SUFDRjtJQUNBLE1BQU0sY0FBYyxhQUFhLGFBQWE7SUFDOUMsV0FDRSxNQUFNLGFBQWEsS0FBSyxTQUFTLElBQUksRUFBRTtNQUNyQyxVQUFVO01BQ1YsTUFBTTtNQUNOO0lBQ0YsR0FDQTtNQUNBLElBQ0UsVUFBVSxJQUFJLEtBQUssU0FBUyxJQUFJLElBQ2hDLFVBQVUsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUNyQjtRQUNBLE1BQU07TUFDUjtJQUNGO0VBQ0Y7RUFFQSxJQUFJLGlCQUE4QjtJQUFDO0dBQWM7RUFDakQsS0FBSyxNQUFNLFdBQVcsU0FBVTtJQUM5Qix3RUFBd0U7SUFDeEUsb0NBQW9DO0lBQ3BDLE1BQU0sZUFBdUMsSUFBSTtJQUNqRCxNQUFNLFFBQVEsR0FBRyxDQUNmLGVBQWUsR0FBRyxDQUFDLE9BQU87TUFDeEIsV0FBVyxNQUFNLGFBQWEsYUFBYSxjQUFjLFNBQVU7UUFDakUsYUFBYSxHQUFHLENBQUMsVUFBVSxJQUFJLEVBQUU7TUFDbkM7SUFDRjtJQUVGLGlCQUFpQjtTQUFJLGFBQWEsTUFBTTtLQUFHLENBQUMsSUFBSSxDQUFDO0VBQ25EO0VBRUEsSUFBSSxnQkFBZ0I7SUFDbEIsaUJBQWlCLGVBQWUsTUFBTSxDQUNwQyxDQUFDLFFBQThCLE1BQU0sV0FBVztFQUVwRDtFQUNBLElBQUksQ0FBQyxhQUFhO0lBQ2hCLGlCQUFpQixlQUFlLE1BQU0sQ0FDcEMsQ0FBQyxRQUE4QixDQUFDLE1BQU0sV0FBVztFQUVyRDtFQUNBLE9BQU87QUFDVDtBQUVBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Q0EwQ0MsR0FDRCxPQUFPLFVBQVUsZUFDZixJQUFrQixFQUNsQixFQUNFLElBQUksRUFDSixVQUFVLEVBQUUsRUFDWixjQUFjLElBQUksRUFDbEIsV0FBVyxJQUFJLEVBQ2YsV0FBVyxJQUFJLEVBQ2YsZUFBZSxFQUNmLGNBQWMsRUFDZCxZQUFZLEVBQ00sR0FBRyxDQUFDLENBQUM7RUFFekIsTUFBTSxFQUNKLFFBQVEsRUFDUixZQUFZLGNBQWMsRUFDMUIsY0FBYyxFQUNkLE9BQU8sRUFDUixHQUFHLE1BQU0sYUFBYTtFQUN2QixTQUFTLGlCQUFpQixXQUFXLE1BQU0sS0FBSyxHQUFHO0VBRW5ELE1BQU0sY0FBMkI7SUFBRTtJQUFVO0lBQVU7RUFBZ0I7RUFDdkUsTUFBTSxVQUFVLGlCQUFpQixPQUFPLFFBQVEsT0FBUSw2QkFBNkI7RUFDckYsTUFBTSxrQkFBa0IsQ0FBQyxPQUF5QixRQUFRLFNBQVM7RUFDbkUsTUFBTSxrQkFBa0IsUUFDckIsR0FBRyxDQUFDLGlCQUNKLEdBQUcsQ0FBQyxDQUFDLElBQXNCLGFBQWEsR0FBRztFQUM5QyxNQUFNLGdCQUFnQixDQUFDLE9BQ3JCLENBQUMsZ0JBQWdCLElBQUksQ0FBQyxDQUFDLElBQXVCLENBQUMsQ0FBQyxLQUFLLEtBQUssQ0FBQztFQUU3RCxJQUFJLFlBQVksaUJBQ1osWUFBWSxZQUFZLFVBQVUsTUFDbEM7RUFDSixNQUFPLFNBQVMsTUFBTSxHQUFHLEtBQUssQ0FBQyxPQUFPLFFBQVEsQ0FBQyxFQUFFLEVBQUk7SUFDbkQsTUFBTSxNQUFNLFNBQVMsS0FBSztJQUMxQixPQUFPLFFBQVE7SUFDZixZQUFZLFVBQVU7TUFBQztNQUFXO0tBQUksRUFBRTtFQUMxQztFQUVBLElBQUk7RUFDSixJQUFJO0lBQ0YsZ0JBQWdCLG9CQUFvQjtFQUN0QyxFQUFFLE9BQU8sT0FBTztJQUNkLE9BQU8sb0JBQW9CO0VBQzdCO0VBRUEsVUFBVSxhQUNSLFFBQW1CLEVBQ25CLFdBQW1CO0lBRW5CLElBQUksQ0FBQyxTQUFTLFdBQVcsRUFBRTtNQUN6QjtJQUNGLE9BQU8sSUFBSSxnQkFBZ0IsTUFBTTtNQUMvQixNQUFNLGFBQWEsVUFBVTtRQUFDLFNBQVMsSUFBSTtRQUFFO09BQUssRUFBRTtNQUNwRCxJQUFJO1FBQ0YsSUFBSSxjQUFjLGFBQWE7VUFDN0IsT0FBTyxNQUFNLG9CQUFvQjtRQUNuQztNQUNGLEVBQUUsT0FBTyxPQUFPO1FBQ2Qsb0JBQW9CO01BQ3RCO01BQ0E7SUFDRixPQUFPLElBQUksZ0JBQWdCLE1BQU07TUFDL0IsT0FBTyxPQUFPLFNBQVMsU0FBUyxJQUFJLEVBQUU7UUFDcEMsTUFBTTtRQUNOLFVBQVUsV0FBVyxXQUFXO1FBQ2hDO1FBQ0E7TUFDRjtJQUNGO0lBQ0EsTUFBTSxjQUFjLGFBQWEsYUFBYTtJQUM5QyxLQUNFLE1BQU0sYUFBYSxTQUFTLFNBQVMsSUFBSSxFQUFFO01BQ3pDLFVBQVU7TUFDVixNQUFNO01BQ047SUFDRixHQUNBO01BQ0EsSUFDRSxVQUFVLElBQUksS0FBSyxTQUFTLElBQUksSUFDaEMsVUFBVSxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQ3JCO1FBQ0EsTUFBTTtNQUNSO0lBQ0Y7RUFDRjtFQUVBLElBQUksaUJBQThCO0lBQUM7R0FBYztFQUNqRCxLQUFLLE1BQU0sV0FBVyxTQUFVO0lBQzlCLHdFQUF3RTtJQUN4RSxvQ0FBb0M7SUFDcEMsTUFBTSxlQUF1QyxJQUFJO0lBQ2pELEtBQUssTUFBTSxnQkFBZ0IsZUFBZ0I7TUFDekMsS0FBSyxNQUFNLGFBQWEsYUFBYSxjQUFjLFNBQVU7UUFDM0QsYUFBYSxHQUFHLENBQUMsVUFBVSxJQUFJLEVBQUU7TUFDbkM7SUFDRjtJQUNBLGlCQUFpQjtTQUFJLGFBQWEsTUFBTTtLQUFHLENBQUMsSUFBSSxDQUFDO0VBQ25EO0VBRUEsSUFBSSxnQkFBZ0I7SUFDbEIsaUJBQWlCLGVBQWUsTUFBTSxDQUNwQyxDQUFDLFFBQThCLE1BQU0sV0FBVztFQUVwRDtFQUNBLElBQUksQ0FBQyxhQUFhO0lBQ2hCLGlCQUFpQixlQUFlLE1BQU0sQ0FDcEMsQ0FBQyxRQUE4QixDQUFDLE1BQU0sV0FBVztFQUVyRDtFQUNBLE9BQU87QUFDVCJ9
// denoCacheMetadata=6455063890661284975,9308664248961335036