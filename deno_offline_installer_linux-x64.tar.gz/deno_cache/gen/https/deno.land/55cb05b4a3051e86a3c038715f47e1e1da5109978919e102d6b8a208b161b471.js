// Copyright 2018-2024 the Deno authors. All rights reserved. MIT license.
/** End-of-line character for POSIX platforms such as macOS and Linux. */ export const LF = "\n";
/** End-of-line character for Windows platforms. */ export const CRLF = "\r\n";
/**
 * End-of-line character evaluated for the current platform.
 *
 * @example
 * ```ts
 * import { EOL } from "https://deno.land/std@$STD_VERSION/fs/eol.ts";
 *
 * EOL; // "\n" on POSIX platforms and "\r\n" on Windows
 * ```
 */ export const EOL = Deno?.build.os === "windows" ? CRLF : LF;
const regDetect = /(?:\r?\n)/g;
/**
 * Returns the detected EOL character(s) detected in the input string. If no EOL
 * character is detected, `null` is returned.
 *
 * @param content The input string to detect EOL characters.
 * @returns The detected EOL character(s) or `null` if no EOL character is detected.
 *
 * @example
 * ```ts
 * import { detect } from "https://deno.land/std@$STD_VERSION/fs/eol.ts";
 *
 * detect("deno\r\nis not\r\nnode"); // "\r\n"
 * detect("deno\nis not\r\nnode"); // "\r\n"
 * detect("deno\nis not\nnode"); // "\n"
 * detect("deno is not node"); // null
 * ```
 */ export function detect(content) {
  const d = content.match(regDetect);
  if (!d || d.length === 0) {
    return null;
  }
  const hasCRLF = d.some((x)=>x === CRLF);
  return hasCRLF ? CRLF : LF;
}
/**
 * Normalize the input string to the targeted EOL.
 *
 * @param content The input string to normalize.
 * @param eol The EOL character(s) to normalize the input string to.
 * @returns The input string normalized to the targeted EOL.
 *
 * @example
 * ```ts
 * import { LF, format } from "https://deno.land/std@$STD_VERSION/fs/eol.ts";
 *
 * const CRLFinput = "deno\r\nis not\r\nnode";
 *
 * format(CRLFinput, LF); // "deno\nis not\nnode"
 * ```
 */ export function format(content, eol) {
  return content.replace(regDetect, eol);
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImh0dHBzOi8vZGVuby5sYW5kL3N0ZEAwLjIyNC4wL2ZzL2VvbC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvLyBDb3B5cmlnaHQgMjAxOC0yMDI0IHRoZSBEZW5vIGF1dGhvcnMuIEFsbCByaWdodHMgcmVzZXJ2ZWQuIE1JVCBsaWNlbnNlLlxuXG4vKiogRW5kLW9mLWxpbmUgY2hhcmFjdGVyIGZvciBQT1NJWCBwbGF0Zm9ybXMgc3VjaCBhcyBtYWNPUyBhbmQgTGludXguICovXG5leHBvcnQgY29uc3QgTEYgPSBcIlxcblwiIGFzIGNvbnN0O1xuXG4vKiogRW5kLW9mLWxpbmUgY2hhcmFjdGVyIGZvciBXaW5kb3dzIHBsYXRmb3Jtcy4gKi9cbmV4cG9ydCBjb25zdCBDUkxGID0gXCJcXHJcXG5cIiBhcyBjb25zdDtcblxuLyoqXG4gKiBFbmQtb2YtbGluZSBjaGFyYWN0ZXIgZXZhbHVhdGVkIGZvciB0aGUgY3VycmVudCBwbGF0Zm9ybS5cbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHNcbiAqIGltcG9ydCB7IEVPTCB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAJFNURF9WRVJTSU9OL2ZzL2VvbC50c1wiO1xuICpcbiAqIEVPTDsgLy8gXCJcXG5cIiBvbiBQT1NJWCBwbGF0Zm9ybXMgYW5kIFwiXFxyXFxuXCIgb24gV2luZG93c1xuICogYGBgXG4gKi9cbmV4cG9ydCBjb25zdCBFT0w6IFwiXFxuXCIgfCBcIlxcclxcblwiID0gRGVubz8uYnVpbGQub3MgPT09IFwid2luZG93c1wiID8gQ1JMRiA6IExGO1xuXG5jb25zdCByZWdEZXRlY3QgPSAvKD86XFxyP1xcbikvZztcblxuLyoqXG4gKiBSZXR1cm5zIHRoZSBkZXRlY3RlZCBFT0wgY2hhcmFjdGVyKHMpIGRldGVjdGVkIGluIHRoZSBpbnB1dCBzdHJpbmcuIElmIG5vIEVPTFxuICogY2hhcmFjdGVyIGlzIGRldGVjdGVkLCBgbnVsbGAgaXMgcmV0dXJuZWQuXG4gKlxuICogQHBhcmFtIGNvbnRlbnQgVGhlIGlucHV0IHN0cmluZyB0byBkZXRlY3QgRU9MIGNoYXJhY3RlcnMuXG4gKiBAcmV0dXJucyBUaGUgZGV0ZWN0ZWQgRU9MIGNoYXJhY3RlcihzKSBvciBgbnVsbGAgaWYgbm8gRU9MIGNoYXJhY3RlciBpcyBkZXRlY3RlZC5cbiAqXG4gKiBAZXhhbXBsZVxuICogYGBgdHNcbiAqIGltcG9ydCB7IGRldGVjdCB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAJFNURF9WRVJTSU9OL2ZzL2VvbC50c1wiO1xuICpcbiAqIGRldGVjdChcImRlbm9cXHJcXG5pcyBub3RcXHJcXG5ub2RlXCIpOyAvLyBcIlxcclxcblwiXG4gKiBkZXRlY3QoXCJkZW5vXFxuaXMgbm90XFxyXFxubm9kZVwiKTsgLy8gXCJcXHJcXG5cIlxuICogZGV0ZWN0KFwiZGVub1xcbmlzIG5vdFxcbm5vZGVcIik7IC8vIFwiXFxuXCJcbiAqIGRldGVjdChcImRlbm8gaXMgbm90IG5vZGVcIik7IC8vIG51bGxcbiAqIGBgYFxuICovXG5leHBvcnQgZnVuY3Rpb24gZGV0ZWN0KGNvbnRlbnQ6IHN0cmluZyk6IHR5cGVvZiBFT0wgfCBudWxsIHtcbiAgY29uc3QgZCA9IGNvbnRlbnQubWF0Y2gocmVnRGV0ZWN0KTtcbiAgaWYgKCFkIHx8IGQubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbiAgY29uc3QgaGFzQ1JMRiA9IGQuc29tZSgoeDogc3RyaW5nKTogYm9vbGVhbiA9PiB4ID09PSBDUkxGKTtcblxuICByZXR1cm4gaGFzQ1JMRiA/IENSTEYgOiBMRjtcbn1cblxuLyoqXG4gKiBOb3JtYWxpemUgdGhlIGlucHV0IHN0cmluZyB0byB0aGUgdGFyZ2V0ZWQgRU9MLlxuICpcbiAqIEBwYXJhbSBjb250ZW50IFRoZSBpbnB1dCBzdHJpbmcgdG8gbm9ybWFsaXplLlxuICogQHBhcmFtIGVvbCBUaGUgRU9MIGNoYXJhY3RlcihzKSB0byBub3JtYWxpemUgdGhlIGlucHV0IHN0cmluZyB0by5cbiAqIEByZXR1cm5zIFRoZSBpbnB1dCBzdHJpbmcgbm9ybWFsaXplZCB0byB0aGUgdGFyZ2V0ZWQgRU9MLlxuICpcbiAqIEBleGFtcGxlXG4gKiBgYGB0c1xuICogaW1wb3J0IHsgTEYsIGZvcm1hdCB9IGZyb20gXCJodHRwczovL2Rlbm8ubGFuZC9zdGRAJFNURF9WRVJTSU9OL2ZzL2VvbC50c1wiO1xuICpcbiAqIGNvbnN0IENSTEZpbnB1dCA9IFwiZGVub1xcclxcbmlzIG5vdFxcclxcbm5vZGVcIjtcbiAqXG4gKiBmb3JtYXQoQ1JMRmlucHV0LCBMRik7IC8vIFwiZGVub1xcbmlzIG5vdFxcbm5vZGVcIlxuICogYGBgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXQoY29udGVudDogc3RyaW5nLCBlb2w6IHR5cGVvZiBFT0wpOiBzdHJpbmcge1xuICByZXR1cm4gY29udGVudC5yZXBsYWNlKHJlZ0RldGVjdCwgZW9sKTtcbn1cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSwwRUFBMEU7QUFFMUUsdUVBQXVFLEdBQ3ZFLE9BQU8sTUFBTSxLQUFLLEtBQWM7QUFFaEMsaURBQWlELEdBQ2pELE9BQU8sTUFBTSxPQUFPLE9BQWdCO0FBRXBDOzs7Ozs7Ozs7Q0FTQyxHQUNELE9BQU8sTUFBTSxNQUFxQixNQUFNLE1BQU0sT0FBTyxZQUFZLE9BQU8sR0FBRztBQUUzRSxNQUFNLFlBQVk7QUFFbEI7Ozs7Ozs7Ozs7Ozs7Ozs7Q0FnQkMsR0FDRCxPQUFPLFNBQVMsT0FBTyxPQUFlO0VBQ3BDLE1BQU0sSUFBSSxRQUFRLEtBQUssQ0FBQztFQUN4QixJQUFJLENBQUMsS0FBSyxFQUFFLE1BQU0sS0FBSyxHQUFHO0lBQ3hCLE9BQU87RUFDVDtFQUNBLE1BQU0sVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDLElBQXVCLE1BQU07RUFFckQsT0FBTyxVQUFVLE9BQU87QUFDMUI7QUFFQTs7Ozs7Ozs7Ozs7Ozs7O0NBZUMsR0FDRCxPQUFPLFNBQVMsT0FBTyxPQUFlLEVBQUUsR0FBZTtFQUNyRCxPQUFPLFFBQVEsT0FBTyxDQUFDLFdBQVc7QUFDcEMifQ==
// denoCacheMetadata=3031527228610081388,18407924701104452657